/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: Chr_Dis_kp184_ka6005P_juntek_esp32ser_20240229_data.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 17-Mar-2024 11:09:30
 */

#ifndef CHR_DIS_KP184_KA6005P_JUNTEK_ESP32SER_20240229_DATA_H
#define CHR_DIS_KP184_KA6005P_JUNTEK_ESP32SER_20240229_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern double freq;
extern boolean_T freq_not_empty;
extern unsigned int state[625];
extern boolean_T isInitialized_Chr_Dis_kp184_ka6005P_juntek_esp32ser_20240229;

#endif
/*
 * File trailer for Chr_Dis_kp184_ka6005P_juntek_esp32ser_20240229_data.h
 *
 * [EOF]
 */
