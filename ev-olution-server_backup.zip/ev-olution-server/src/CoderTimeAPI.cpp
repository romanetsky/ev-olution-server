/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: CoderTimeAPI.c
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 17-Mar-2024 11:09:30
 */

/* Include Files */
#include "CoderTimeAPI.h"
#include "Chr_Dis_kp184_ka6005P_juntek_esp32ser_20240229_data.h"
#include "rt_nonfinite.h"
#include "coder_posix_time.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void c_CoderTimeAPI_callCoderClockGe(void)
{
  freq_not_empty = false;
}

/*
 * File trailer for CoderTimeAPI.c
 *
 * [EOF]
 */
