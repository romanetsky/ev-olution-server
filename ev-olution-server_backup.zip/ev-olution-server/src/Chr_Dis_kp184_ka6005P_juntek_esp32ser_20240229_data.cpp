/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: Chr_Dis_kp184_ka6005P_juntek_esp32ser_20240229_data.c
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 17-Mar-2024 11:09:30
 */

/* Include Files */
#include "Chr_Dis_kp184_ka6005P_juntek_esp32ser_20240229_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
double freq;

boolean_T freq_not_empty;

unsigned int state[625];

boolean_T isInitialized_Chr_Dis_kp184_ka6005P_juntek_esp32ser_20240229 = false;

/*
 * File trailer for Chr_Dis_kp184_ka6005P_juntek_esp32ser_20240229_data.c
 *
 * [EOF]
 */
